'''

Ruidos estacionarios:
	60hz del suministro de energia (ver espectrograma)

Ruidos no estacionarios:
	Ruido (dinamico?) natural
	Ruido al final de la senial, flasho la medicion

'''
